﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для Connect.xaml
    /// </summary>
    public partial class PersonalArea : Window
    {
        string name;
        public PersonalArea(string nick)
        {    
            InitializeComponent();
           name = nick;
        }
		
        MySqlConnection mysql_dbc;

        Registration reg = new Registration();
        string host = "sql4.freemysqlhosting.net"; // Имя хоста
        string user = "sql4478918"; // Имя пользователя
        string database = "sql4478918"; // Имя базы данных
        string password = "fYi7Kpf7uh"; // Пароль
        DateTime myDateTime;



        private void ChangePassButton_Click(object sender, RoutedEventArgs e)
        {
            ChangePass change = new ChangePass(name);
            change.Show();
        }

        private void Form3_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {

        }
    }
}
