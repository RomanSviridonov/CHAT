﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для Registration.xaml
    /// </summary>
    public partial class Registration : Window
    {
        public Registration()
        {
            InitializeComponent();
        }

        string host = "sql4.freemysqlhosting.net"; // Имя хоста
        string user = "sql4478918"; // Имя пользователя
        string database = "sql4478918"; // Имя базы данных
        string password = "fYi7Kpf7uh"; // Пароль
        MySqlConnection mysql_dbc;

        bool temp = true;

        private void RegRegButton_Click(object sender, RoutedEventArgs e)
        {
            string con = "Database=" + database + ";Data Source=" + host + ";User=" + user + ";Password=" + password;

            mysql_dbc = new MySqlConnection(con);
            mysql_dbc.Open();
            string sql = "INSERT INTO `users` (`name`, `password`) VALUES ('" + RegLoginBox.Text + "', '" + RegPasswordBox.Password + "')";
            MySqlCommand cmd = new MySqlCommand(sql, mysql_dbc);
            cmd.ExecuteNonQuery();
            mysql_dbc.Close();
            this.Close();
        }

        private void ShowPassword_Checked(object sender, RoutedEventArgs e)
        {
            RegPasswordTXTBox.Text = RegPasswordBox.Password;
            RegPasswordBox.Visibility = Visibility.Collapsed;
            RegPasswordTXTBox.Visibility = Visibility.Visible;
        }

        private void ShowPassword_Unchecked(object sender, RoutedEventArgs e)
        {
            RegPasswordBox.Password = RegPasswordTXTBox.Text;
            RegPasswordTXTBox.Visibility = Visibility.Collapsed;
            RegPasswordBox.Visibility = Visibility.Visible;
        }

        private void LoginBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (temp)
            {
                RegLoginBox.Text = string.Empty;
                RegLoginBox.Foreground = new SolidColorBrush(Colors.Black);
                temp = false;
            }
        }

        private void LoginBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (string.IsNullOrEmpty(RegLoginBox.Text) && !temp)
            {
                RegLoginBox.Text = "Введите логин";
                RegLoginBox.Foreground = new SolidColorBrush(Colors.Gray);
                temp = true;

            }
        }

        private void passwordBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (temp)
            {
                RegPasswordBox.Password = "";
                RegPasswordBox.Foreground = new SolidColorBrush(Colors.Black);
                temp = false;
            }
        }

        private void passwordBox_PasswordChanged(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(RegPasswordBox.Password) && !temp)
            {
                RegPasswordBox.Password = "Введите пароль";
                RegPasswordBox.Foreground = new SolidColorBrush(Colors.Gray);
                temp = true;

            }
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            Connect frm = new Connect();
            frm.Show();
        }
    }
}