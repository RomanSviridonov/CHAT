﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;
using System.Data;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для Personal.xaml
    /// </summary>
    public partial class Personal : Window
    {
        public Personal(string nick)
        {
            InitializeComponent();
            nickN = nick;
            
        }
        string nickN;
        string host = "sql4.freemysqlhosting.net"; // Имя хоста
        string user = "sql4478918"; // Имя пользователя
        string database = "sql4478918"; // Имя базы данных
        string password = "fYi7Kpf7uh"; // Пароль

        
        PersonalChat personalCh;
        MySqlConnection mysql_dbc;


        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            string con = "Database=" + database + ";Data Source=" + host + ";User=" + user + ";Password=" + password + ";convert zero datetime=True";

            MySqlConnection myConnection = new MySqlConnection(con);
            myConnection.Open();
            string query = "SELECT * FROM users";
            MySqlCommand command = new MySqlCommand(query, myConnection);

            command.ExecuteNonQuery();
            MySqlDataAdapter dataAdp = new MySqlDataAdapter(command);
            DataTable dt = new DataTable("Пользователи");
            dataAdp.Fill(dt);
            Friends.ItemsSource = dt.DefaultView;
            Friends.Columns.RemoveAt(0);
            Friends.Columns.RemoveAt(1);
            Friends.Columns.RemoveAt(1);

            myConnection.Close();

            LabelName.Content = nickN;

        }



        private void ListBoxItem_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            //object name = FriendsBox.SelectedItem;
            MessageBox.Show("gg", "g");
        }
        private void Friends_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            
            int selectedColumn = Friends.CurrentCell.Column.DisplayIndex;
            var selectedCell = Friends.SelectedCells[selectedColumn];
            var cellContent = selectedCell.Column.GetCellContent(selectedCell.Item);
            FriendName.Content = (cellContent as TextBlock).Text;
            personalCh = new PersonalChat();
            personalCh.Owner = this;
            if (cellContent is TextBlock)
            {
                
                personalCh.Show();
            }
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            string con = "Database=" + database + ";Data Source=" + host + ";User=" + user + ";Password=" + password;
            mysql_dbc = new MySqlConnection(con);
            mysql_dbc.Open();
            string sql = "UPDATE users SET Activity = 'Offline' WHERE name = '" + nickN + "'";
            MySqlCommand cmd = new MySqlCommand(sql, mysql_dbc);
            cmd.ExecuteNonQuery();
            mysql_dbc.Close();

            Connect Main = (Connect)this.Owner;
            Main.Show();
        }
    }
}
