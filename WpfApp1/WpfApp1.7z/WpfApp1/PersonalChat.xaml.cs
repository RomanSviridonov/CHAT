﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.IO;
using System.Net;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для PersonalChat.xaml
    /// </summary>
    public partial class PersonalChat : Window
    {
        public PersonalChat()
        {
            InitializeComponent();
            update();
        }

        MySqlConnection mysql_dbc;

        Registration reg = new Registration();
        string host = "sql4.freemysqlhosting.net"; // Имя хоста
        string user = "sql4478918"; // Имя пользователя
        string database = "sql4478918"; // Имя базы данных
        string password = "fYi7Kpf7uh"; // Пароль
        string myName;

        bool updater = true;
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Personal pers = (Personal)this.Owner;
            FriendLabel.Content = pers.FriendName.Content;
            LabelName.Content = pers.LabelName.Content;
            LoadTextDocument();
            
        }
        private async void update()
        {
            while (updater == true)
            {
                ChatBox.Clear();
                
                LoadTextDocument();
                await Task.Delay(500);
            }
            LoadTextDocument();
        }
        string name;
        string con = "Database=sql4478918;Data Source=sql4.freemysqlhosting.net;User=sql4478918;Password=fYi7Kpf7uh;convert zero datetime=True;Charset=UTF8";
        private void LoadTextDocument()
        {
            
            mysql_dbc = new MySqlConnection(con);
            mysql_dbc.Open();
            string sql = "SELECT message FROM messages WHERE (fromName='" + LabelName.Content + "' AND toName='" + FriendLabel.Content + "') or (fromName='" + FriendLabel.Content + "' AND toName='" + LabelName.Content + "')";
            MySqlCommand cmd = new MySqlCommand(sql, mysql_dbc);
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                ChatBox.Text += reader["message"].ToString() + "\n";
            }
            mysql_dbc.Close();
        }


        private void Window_Closed(object sender, EventArgs e)
        {
            updater = false;
            Personal pers = (Personal)this.Owner;
            pers.Show();
            
        }
        string nick;
        string sql1;
        private void SendButton_Click(object sender, RoutedEventArgs e)
        {
            mysql_dbc = new MySqlConnection(con);
            mysql_dbc.Open();
            nick = LabelName.Content.ToString();
            sql1 = "INSERT INTO messages(`fromName`, `toName`, `message`) VALUES ('"+ LabelName.Content +"', '"+ FriendLabel.Content +"', '"+ DateTime.Now + " | " + nick + ": " + TextEnter.Text +"')";
            MySqlCommand sql1_cmd = new MySqlCommand(sql1, mysql_dbc);
            sql1_cmd.ExecuteNonQuery();

            TextEnter.Clear();
            ChatBox.ScrollToEnd();
            mysql_dbc.Close();
        }
    }
}
